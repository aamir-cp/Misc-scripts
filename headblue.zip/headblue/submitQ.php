<?php require('./../../../wp-load.php'); ?><?php
print_r ($_POST);

//die();
 $user = get_user_by( 'email', $_POST['theEmail'] );
$user_id = $user->ID;
// print_r($_POST['email']);   

for ($x = 1; $x < 100; $x++) {
    if($_POST["question$x"] != ""){
    update_user_meta( $user_id, "question".$x, $_POST["question$x"]); 
    }
}
 

    
