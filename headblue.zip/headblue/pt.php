<?php
function the_post_type() {
	$pt_labels = array(
		'name'                  => _x( ucfirst($_SESSION['cpt']), 'Post Type General Name', $_SESSION['cpt'] ),
		'singular_name'         => _x( ucfirst($_SESSION['cpt']), 'Post Type Singular Name', $_SESSION['cpt'] ),
		'menu_name'             => __( ucfirst($_SESSION['cpt']), $_SESSION['cpt'] ),
		'name_admin_bar'        => __( ucfirst($_SESSION['cpt']), $_SESSION['cpt'] ),
		'archives'              => __( 'Item Archives', $_SESSION['cpt'] ),
		'parent_item_colon'     => __( 'Parent Item:', $_SESSION['cpt'] ),
		'all_items'             => __( 'All '.ucfirst($_SESSION['cpt']),$_SESSION['cpt'] ),
		'add_new_item'          => __( 'Add New '. ucfirst($_SESSION['single_name']), $_SESSION['cpt'] ),
		'add_new'               => __( 'Add New '. ucfirst($_SESSION['single_name']), $_SESSION['cpt']),
		'new_item'              => __( 'New Item', $_SESSION['cpt'] ),
		'edit_item'             => __( 'Edit Item', $_SESSION['cpt'] ),
		'update_item'           => __( 'Update Item', $_SESSION['cpt'] ),
		'view_item'             => __( 'View Item', $_SESSION['cpt'] ),
		'search_items'          => __( 'Search Item', $_SESSION['cpt'] ),
		'not_found'             => __( 'Not found', $_SESSION['cpt'] ),
		'not_found_in_trash'    => __( 'Not found in Trash', $_SESSION['cpt'] ),
		'featured_image'        => __( 'Featured Image', $_SESSION['cpt'] ),
		'set_featured_image'    => __( 'Set featured image', $_SESSION['cpt'] ),
		'remove_featured_image' => __( 'Remove featured image', $_SESSION['cpt'] ),
		'use_featured_image'    => __( 'Use as featured image', $_SESSION['cpt'] ),
		'insert_into_item'      => __( 'Insert into item', $_SESSION['cpt'] ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', $_SESSION['cpt'] ),
		'items_list'            => __( 'Items list', $_SESSION['cpt'] ),
		'items_list_navigation' => __( 'Items list navigation', $_SESSION['cpt'] ),
		'filter_items_list'     => __( 'Filter items list', $_SESSION['cpt'] ),
	);
	$pt_args = array(
		'label'                 => __( $_SESSION['cpt'], $_SESSION['cpt'] ),
		'description'           => __( $_SESSION['cpt'].' information page.', $_SESSION['cpt'] ),
		'labels'                => $pt_labels,
		'supports'              => array( 'title', 'editor','author', 'thumbnail', 'revisions', ),
		'taxonomies'            => array( 'categories' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 13,
		'menu_icon'             => 'dashicons-excerpt-view',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( $_SESSION['cpt'], $pt_args );
}
add_action( 'init', 'the_post_type', 0 );

////////////////

///////SUBMENU
//SUBMENU IN settingFields.php

/***===========================================================================================================***/
function admin_subpage() {
    /*********=====================================================================================================
     * SUB PAGE FOR SETTINGS HERE=======================
     *****==============================================*/
//    include_once('settingsFields.php');

//    if( is_admin() )
     $settings_page= new SettingsPage();
$settings_page->create_admin_page();
}
///////CUSTOM MESSAGES
function my_updated_messages( $messages ) {
  global $post, $post_ID;
  $messages[$_SESSION['cpt']] = array(
    0 => '', 
    1 => sprintf( __(ucfirst($_SESSION['single_name']).' updated. <a href="%s">View '.ucfirst($_SESSION['single_name']).'</a>'), esc_url( get_permalink($post_ID) ) ),
    2 => __('Custom field updated.'),
    3 => __('Custom field deleted.'),
    4 => __(ucfirst($_SESSION['single_name']).' updated.'),
    5 => isset($_GET['revision']) ? sprintf( __(ucfirst($_SESSION['single_name']).' restored to revision from %s'), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
    6 => sprintf( __(ucfirst($_SESSION['single_name']).' published. <a href="%s">View '.ucfirst($_SESSION['single_name']).'</a>'), esc_url( get_permalink($post_ID) ) ),
    7 => __(ucfirst($_SESSION['single_name']).' saved.'),
    8 => sprintf( __(ucfirst($_SESSION['single_name']).' submitted. <a target="_blank" href="%s">Preview '.ucfirst($_SESSION['single_name']).'</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
    9 => sprintf( __(ucfirst($_SESSION['single_name']).' scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview '.ucfirst($_SESSION['single_name']).'</a>'), date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ), esc_url( get_permalink($post_ID) ) ),
    10 => sprintf( __(ucfirst($_SESSION['single_name']).' draft updated. <a target="_blank" href="%s">Preview '.ucfirst($_SESSION['single_name']).'</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
  );
  return $messages;
}
add_filter( 'post_updated_messages', 'my_updated_messages' );

/*
|===================================================================================|
|																					|
|       Meta Box                                               |
|																					|
|===================================================================================| 
 */
// Add the Meta Box
function add_cpt_meta_box() {
    echo $options['should_show'];
    add_meta_box(
        'custom_meta_box', // $id
        'Details', // $title 
        'show_cpt_meta_box', // $callback
        $_SESSION['cpt'], // $page
        'normal', // $context
        'high'
    ); // $priority
    add_meta_box(
        'custom_side_box', // $id
        'Question Number', // $title 
        'show_side_box', // $callback
        $_SESSION['cpt'], // $page
        'side', // $context
        'high'
    ); // $priority
}
add_action('add_meta_boxes', 'add_cpt_meta_box');
 // Field Array
$metafield_prefix = 'headblue_';

 
// The Callback
function show_side_box() {
	global $cpt_meta_fields_options, $post;
?>
<table style="padding:10px 0;">
    <tr>
        <th><label id="qnl" for="question_number">Question number:</label></th>
        <td><select name="question_number" id="question_number" class="form-control">
                <option></option>
                <?php $stored_pos = get_post_meta($post->ID, 'question_number', true);?>
            <?php for($n = 1; $n <= 40; $n++):?>
                <option value="<?=$n?>" <?=($stored_pos==$n?'selected':'');?>><?=$n?></option>
            <?php endfor;?></select>
            <!--<input type="text"value="<?=get_post_meta($post->ID, 'question_number', true);?>">-->
        </td>
    </tr>
</table>
<?php }   
// The Callback
function show_cpt_meta_box() {
	global $cpt_meta_fields_options, $post;
?>
<style>
/*TABS CSS*/.tabset>input[type=radio] {	position:absolute;	left:-200vw}.tabset .tab-panel {	display:none}
.tabset>input:first-child:checked~.tab-panels>.tab-panel:first-child, .tabset>input:nth-child(11):checked~.tab-panels>.tab-panel:nth-child(6), .tabset>input:nth-child(3):checked~.tab-panels>.tab-panel:nth-child(2), .tabset>input:nth-child(5):checked~.tab-panels>.tab-panel:nth-child(3), .tabset>input:nth-child(7):checked~.tab-panels>.tab-panel:nth-child(4), .tabset>input:nth-child(9):checked~.tab-panels>.tab-panel:nth-child(5) {
display:block}
.tabset>label {	position:relative;	display:inline-block;	padding:8px 30px;	cursor:pointer;	font-weight:600;	border:1px solid #006698;	border-radius:5px}
.tabset>input:focus+label, .tabset>label:hover {	color:#06c}
.tabset>input:checked+label {	background:#0085BA;	color:#fff}
.tab-panel {	padding:30px 0}
input[type="text"], input[type="email"], input[type="password"] {width: 94%;padding:8px 10px;    border-radius: 5px;    border: 1px solid #ABC;}
#question_number{max-width: 80px;padding: 5px;height: 45px;}#qnl, #question_number{font-size: 17px;}
</style>
<input type="hidden" name="custom_meta_box_nonce" value="<?=wp_create_nonce(basename(__FILE__));?>">
<?php $qtype=get_post_meta($post->ID, 'qtype', true);?>
<!--<input type="hidden" name="qtype" id="qtype" value="<?=(($qtype!="")?qtype:'');?>"/>-->
<input type="hidden" name="qtype" id="qtype" value="<?=get_post_meta($post->ID, 'qtype', true);?>"/>

<h3>Select the type of question, you want to add:</h3>
<div class="tabset"> 
  <!-- Tab 1 -->
  <input type="radio" name="tabset" id="multiple" aria-controls="multiple_sect" value="multiple" <?php if(isset($qtype)){if($qtype=='multiple'){?>checked<?php }}else{?>checked<?php }?>>
  <label for="multiple" id="tab1">Multiple</label>
  <!-- Tab 2 -->
  <input type="radio" name="tabset" id="text" aria-controls="text_sect" value="text" <?php if(isset($qtype)){if($qtype=='text'){?>checked<?php }}?>>
  <label for="text" id="tab2">Text</label>
  <!-- Tab 3 -->
  <input type="radio" name="tabset" id="upl" aria-controls="upload_sect" value="upload" <?php if(isset($qtype)){if($qtype=='upload'){?>checked<?php }}?>>
  <label for="upl" id="tab3">Upload</label>
  <!-- Tab 4 -->
  <input type="radio" name="tabset" id="cond" aria-controls="cond_sect" value="cond_q" <?php if(isset($qtype)){if($qtype=='cond_q'){?>checked<?php }}?>>
  <label for="cond" id="tab4">Conditional Question</label>
  <div class="tab-panels">
    <section id="multiple_sect" class="tab-panel">   
      <h4>This option will add a multiple choice question.</h4>
      <table class="form-table"><tbody>
      <?php for ($opt = 1; $opt <= 6; $opt++): ?>
      <?php 
switch ($opt) {
    case 1:
        $alp = "One";
        break;
    case 2:
         $alp = "Two";
        break;
    case 3:
         $alp = "Three";
        break;
    case 4:
         $alp = "Four";
        break;
    case 5:
         $alp = "Five";
        break;
    case 6:
         $alp = "Six";
        break;   
};?>
      <tr>
                <th class="headblue_opt_<?=$opt;?>_td_header"><label for="hb_q_opt_<?=$opt;?>">Option <?=$alp;?></label></th>
                <td class="headblue_opt_<?=$opt;?>_td_class"><input type="text" name="hb_q_opt_<?=$opt;?>" id="hb_q_opt_<?=$opt;?>" value="<?=get_post_meta($post->ID, 'hb_q_opt_'.$opt, true);?>" size="30" class="form-control">
        <br><span class="description"></span></td>
      </tr>
      <?php endfor;?>    
        
        </tbody></table>
      
      </section>
    <section id="text_sect" class="tab-panel">
     <h4>This option will add a simple text question.</h4>
      </section>
    <section id="upload_sect" class="tab-panel">
      <!--<h2>Upload</h2>-->
      <h4>This option will add a text question with file upload.</h4>
            <tr>
                <th class="headblue_additionalinfo_header"><label for="hb_upl_additional">Additional Info</label></th>
                <td class="headblue_additionalinfo_class"><input type="text" name="hb_upl_additional" id="hb_upl_additional" value="<?=get_post_meta($post->ID, 'hb_upl_additional', true);?>" size="30" class="form-control">
        <br><span class="description"></span></td></tr>
</section>
    <section id="cond_sect" class="tab-panel">
<h4>This option will add a conditional text question.</h4>
<tr>
    <th class="headblue_conditionalinfo_header"><label for="hb_cond_q">Conditional Question</label></th>
    <td class="headblue_conditionalinfo"><input type="text" name="hb_cond_q" id="hb_cond_q" value="<?=get_post_meta($post->ID, 'hb_cond_q', true);?>" size="30" class="form-control">
<br><span class="description"></span></td>
</tr>
      </section>
  </div>
</div>

<script>
(function($){
	$(document).ready(function(){

		$('#multiple').click(function(){
			/*$('#multiple_sect input').val('');*/
			$('#upload_sect input').val('');
			$('#qtype').val("multiple");
                        $('#cond_sect input').val('');
		});
                $('#text').click(function(){
			$('#multiple_sect input').val('');
			$('#upload_sect input').val('');
                        $('#cond_sect input').val('');
                        $('#qtype').val("text");
		});
		$('#upl').click(function(){
			$('#multiple_sect input').val('')
			$('#cond_sect input').val('');
                        $('#qtype').val("upload");
		});
		$('#cond').click(function(){
			$('#multiple_sect input').val('');
			$('#text input').val('');
			$('#upload_sect input').val('');
                        $('#qtype').val("cond_q");
		});
                
	});
	})(jQuery);	
</script>
<?php }
// Save+Update the Data
function save_cpt_meta($post_id) {
        global $cpt_meta_fields_options, $post;
        update_post_meta($post->ID, "question_number", $_POST["question_number"]);
	
        for ($opt = 1; $opt <= 6; $opt++){
	 update_post_meta($post->ID, "hb_q_opt_".$opt, $_POST["hb_q_opt_".$opt]);
	}	 
	
        update_post_meta($post->ID, "hb_upl_additional", $_POST["hb_upl_additional"]);
	
        update_post_meta($post->ID, "hb_cond_q", $_POST["hb_cond_q"]);
        
	update_post_meta($post->ID, "qtype", $_POST["qtype"]);
}
add_action('save_post', 'save_cpt_meta');
//rem edit frm pt
add_action('init', 'my_rem_editor_from_post_type');
function my_rem_editor_from_post_type() {
    remove_post_type_support( 'questions', 'editor' );
}