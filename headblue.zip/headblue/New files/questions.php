<input type="hidden" name="theEmail" id="theEmail"/>
<?php
    $qn=1;
    //$query = new WP_Query(array('post_type' => 'questions', 'author' => $authorID));
    $query = new WP_Query(array('post_type' => 'questions', "orderby" => 'meta_value_num',"meta_key" => 'question_number',"order" => 'ASC'));?>
<?php if($query->have_posts()): ?>
<?php while ( $query->have_posts() ) : $query->the_post();?>
<?php  $questions = $query->posts; ?>
<?php  $total_questions = count($questions);?>
<?php     
// echo '<pre>';
//  print_r($questions);
    ?>
<!-- QUESTION <?=$qn;?>-->
<style>#val_question7_2{display:none !important;}</style>
<section class="tab hide <?=($qn == $total_questions ? 'last' : '' );?>" id="q<?=$qn;?>">
  <div class="row">
    <div class="col-lg-12 m-t-10">
      <?php if($qn ==1){?>
      <p>To start, you have to complete this simple quiz:</p>
      <?php }?>
    </div>
  </div>
  <div class="row">
    <div class="col-lg-3 p-t-8 text-center"> 
      <a class="commonBtn <?=($qn == 1 ? 'hide' : '' );?> prev" id="prevBtn" href="javascript:void(0)">Back</a> 
    </div>
    <div class="col-lg-6 text-center">
      <?php $progress = $qn*100/$total_questions; //$_SESSION["progress"] = $progress;?>
      <span id="prog" style="display:none">
      <?=$total_questions?>
      </span>
      <h3 id="progessValue">Progress <span>
        <?=floor($progress);?>
        </span>%</h3>
    </div>
    <div class="col-lg-3 p-t-8"> <a class="commonBtn next <?=($qn == $total_questions ? 'hide' : '' );?>" href="javascript:void(0)">Next</a> </div>
  </div>
  <div class="row m-t-20">
    <div class="col-lg-12 m-t-10 mb-3">
      <div id="question-bar" class="progress progressQuestionWidth">
        <div id="qprogress" class="question-bar bg-info" role="progressbar" style="width: <?=$progress;?>%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-lg-12 m-t-10">
      <h4>
        <?= the_title(); ?>
      </h4>
    </div>
  </div>
  <?php $qtype = get_post_meta(get_the_ID(),'qtype', true); ?>
  <?php $hb_q_opt_1 = get_post_meta(get_the_ID(),'hb_q_opt_1', true); ?>
  <?php $hb_q_opt_2 = get_post_meta(get_the_ID(),'hb_q_opt_2', true); ?>
  <?php $hb_q_opt_3 = get_post_meta(get_the_ID(),'hb_q_opt_3', true); ?>
  <?php $hb_q_opt_4 = get_post_meta(get_the_ID(),'hb_q_opt_4', true); ?>
  <?php $hb_q_opt_5 = get_post_meta(get_the_ID(),'hb_q_opt_5', true); ?>
  <?php $hb_q_opt_6 = get_post_meta(get_the_ID(),'hb_q_opt_6', true); ?>
  <?php $hb_cond_q = get_post_meta(get_the_ID(),'hb_cond_q', true); ?>
  <?php //$hb_q_opt_1 = get_post_meta(get_the_ID(),'opt_1', true); ?>
  <?php $hb_upl_additional = get_post_meta(get_the_ID(),'hb_upl_additional', true); ?>
  <?php if($qtype == 'multiple'){?>
  <div class="inputDiv">
    <div class="row m-t-10">
      <div class="col-lg-12">
        <label>
          <input class="checkboxMulti" type="checkbox" id="val_question<?=$qn?>_1" name="val_question<?=$qn?>[]" value="<?=$hb_q_opt_1;?>"/>
          <span>
          <?=$hb_q_opt_1;?>
          </span></label>
      </div>
    </div>
  </div>
    <?php if($hb_q_opt_2 != ""){?>
  <div class="inputDiv">
    <div class="row">
      <div class="col-lg-12">
        <label>
          <input class="checkboxMulti"  type="checkbox" id="val_question<?=$qn?>_2" name="val_question<?=$qn?>[]" value="<?=$hb_q_opt_2;?>"/>
          <span>
          <?=$hb_q_opt_2;?>
          </span></label>
      </div>
    </div>
  </div>
    <?php }?>
  <?php if($hb_q_opt_3 != ""){?>
  <div class="inputDiv">
    <div class="row">
      <div class="col-lg-12">
        <label>
          <input class="checkboxMulti" type="checkbox" id="val_question<?=$qn?>_3" name="val_question<?=$qn?>[]" value="<?=$hb_q_opt_3;?>"/>
          <span>
          <?=$hb_q_opt_3;?>
          </span></label>
      </div>
    </div>
  </div>
  <?php }?>
  <?php if($hb_q_opt_4 != ""){?>
  <div class="inputDiv">
    <div class="row">
      <div class="col-lg-12">
        <label>
          <input class="checkboxMulti" type="checkbox" id="val_question<?=$qn?>_4" name="val_question<?=$qn?>[]" value="<?=$hb_q_opt_4;?>"/>
          <span>
          <?=$hb_q_opt_4;?>
          </span></label>
      </div>
    </div>
  </div>
  <?php }?>
  <?php if($hb_q_opt_5 != ""){?>
  <div class="inputDiv">
    <div class="row">
      <div class="col-lg-12">
        <label>
          <input class="checkboxMulti" type="checkbox" id="val_question<?=$qn?>_5" name="val_question<?=$qn?>[]" value="<?=$hb_q_opt_5;?>"/>
          <span>
          <?=$hb_q_opt_5;?>
          </span></label>
      </div>
    </div>
  </div>
  <?php }?>
  <?php if($hb_q_opt_6 != ""){?>
  <div class="inputDiv">
    <div class="row">
      <div class="col-lg-12">
        <label>
          <input class="checkboxMulti" type="checkbox" id="question<?=$qn?>_6" name="val_question<?=$qn?>[]" value="<?=$hb_q_opt_6;?>"/>
          <span>
          <?=$hb_q_opt_6;?>
          </span></label>
      </div>
    </div>
  </div>
  <?php }?>
    
  <div class="inputDiv m-t-10">
    <div class="row">
      <div class="col-lg-12">
        <label>
            <span>
          If Other Write:
          </span>
            <div class=" m-t-10"></div>
          <input class="hb_other" type="text" id="question<?=$qn?>_other" name="val_question<?=$qn?>_other" value="" style="border: 1px solid #CCC;"/>
          </label>
      </div>
    </div>
  </div>
    
  <?php }elseif($qtype == 'text'){?>
  <div class="inputDiv">
    <div class="row m-t-10">
      <div class="col-lg-12">
        <input type="text" id="val_question<?=$qn?>" name="val_question<?=$qn?>" value="" placeholder="Please enter your answer here"/>
        <span></span> </div>
    </div>
  </div>
  <?php }elseif($qtype == 'upload'){?>
  <div class="inputDiv">
    <div class="row m-t-10">
      <div class="col-lg-12">
        <?php if($hb_upl_additional != ""):?>
        <?=$hb_upl_additional;?>
        <?php endif;?>
        <span></span><br/>
      </div>
    </div>
  </div>
  <div class="inputDiv">
    <div class="row m-t-10">
      <div class="col-lg-12">
        <input type="hidden" name="is_upload" id="is_upload" value="true"/>
        
        <div id="upload1" class=" m-t-10">
        <input type="file" id="file_upload<?=$qn?>_1" name="file_upload<?=$qn?>_1" class="file_upload m-t-10"/>
        <button type="button" class="commonBtn upl_btn m-t-10" name="upl_btn<?=$qn?>_1" id="upl_btn<?=$qn?>_1">Upload</button>
        <input type="hidden" name="q<?=$x?>_upload1_val" id=q<?=$x?>_"upload1_val">
        </div>
        
        
        <div id="upload2" class=" m-t-10">
        <input type="file" id="file_upload<?=$qn?>_2" name="file_upload<?=$qn?>_2" class="file_upload m-t-10"/>
        <button type="button" class="commonBtn upl_btn m-t-10" name="upl_btn<?=$qn?>_2" id="upl_btn<?=$qn?>_2">Upload</button>
        <input type="hidden" name="q<?=$x?>_upload2_val" id="q<?=$x?>_upload2_val">
        </div>
        
        
        <div id="upload3" class=" m-t-10">
        <input type="file" id="file_upload<?=$qn?>_3" name="file_upload<?=$qn?>_3" class="file_upload m-t-10"/>
        <button type="button" class="commonBtn upl_btn m-t-10" name="upl_btn<?=$qn?>_3" id="upl_btn<?=$qn?>_3">Upload</button>
        <input type="hidden" name="q<?=$x?>_upload3_val" id="q<?=$x?>_upload3_val">
        </div>
        
        <span></span>
        <div class="col-sm-12 text-danger upl_resp" id="upl_resp<?=$qn?>"></div>
      </div>
    </div>
  </div>
   <?php }elseif($qtype == 'cond_q'){?>
    <div class="inputDiv">
    <div class="row m-t-10">
      <div class="col-lg-12">
          <label><input type="radio" id="val_question<?=$qn?>_yes" name="val_question<?=$qn?>" value="yes"/>Yes</label>
          <label><input type="radio" id="val_question<?=$qn?>_no" name="val_question<?=$qn?>" value="no"/> No</label>
        <span></span><br/>
      </div>
    </div>
  </div>
  <div class="inputDiv">
    <div class="row m-t-10">
      <div class="col-lg-12">
        <?php if($hb_cond_q != ""):?>
        <?=$hb_cond_q;?>
          <input type="text" class="" id="val_cond_question<?=$qn?>" name="val_cond_question<?=$qn?>" value="" placeholder="Please enter your answer here"/>
        <?php endif;?>
        <span></span>
        <div class="col-sm-12 text-danger upl_resp" id="upl_resp<?=$qn?>"></div>
      </div>
    </div>
  </div>
  <?php  }?>
  <?php  if($qn == $total_questions):?>
  <div class="row m-t-20">
    <div class="col-md-12">
      <button type="submit" class="commonBtn submit next" name="final" id="final">Finish</button>
    </div>
  </div>
  <?php endif;?>
</section>
<input type="hidden" name="question<?=$qn?>" id="question<?=$qn?>"/>
<?php $qn++;?>
<?php endwhile; ?>
<?php endif; ?>
<?php // return ob_get_clean();   
?>