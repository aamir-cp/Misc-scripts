<?php

function hb_lead_form() {
    ob_start();
    global $post;
    ?><?php $options = get_option('hb_options');?>  
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo plugin_dir_url(__FILE__) ?>/assets/style.css">
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;1,100;1,200;1,300;1,400;1,500;1,600&display=swap" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js" type="text/javascript"></script>
<style>
.hide  {display:none !important;}
.label {line-height: 38px;    cursor: pointer;text-transform:capitalize;}
#priceOutput {font-size: 30px;font-weight: bold;color: #1481af;}
@media only screen and (min-width: 1000px) {
#priceOutput {font-size: 50px;font-weight: bold;color: #1481af;}
}
#final {float:right;}
.headblue-form, #hb-user, .commonDiv, .bgWhite, .tab {width: 100%;}
.text-center{padding:15px 0;}
 .left {float: left !important;    width: 49% !important;}
 .right {float: left !important;    width: 49% !important;}
 .searchDiv {    position: relative;}
 @media only screen and (max-width: 767px) { label.label {    float: left;} }
#processing{position:relative;top:-50%;display:none;width:100% !important;height: 100% !important;color:#1481AF;font-size:30px;text-align: center;padding:20%;}
input[type="range"] {border: none !important;outline: none !important;box-shadow: none !important;}
</style>
<section class="headblue-form">
    <form action="" method="post" id="hb-user" enctype="multipart/form-data">
  <div class="commonDiv">
    <div class="bgWhite">
      <div class="container">

        <section class="tab" id="step1">
          <div class="row">
            <div class="col-lg-3 col-md-4 col-sm-12 p-t-8 text-center"> 
              <!--<a class="commonBtn" id="prev" href="#" onclick="nextPrev(-1)">Back</a>--> 
            </div>
            <div class="col-lg-6 col-md-4 col-sm-12 text-center">
              <h3 id="stepValue">STEP 1/3</h3>
            </div>
            <div class="col-lg-3 p-t-8 col-md-4 col-sm-12"> <a class="commonBtn next" id="next" href="javascript:void(0)">Next</a> </div>
          </div>
          <div class="row m-t-20">
            <div class="col-lg-12 col-md-12 col-sm-12">
              <div id="bar" class="progress progressWidth">
                <div class="progress-bar bg-info" role="progressbar" style="width: 33.3%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
          </div>
          <div class="row m-t-10">
            <div class="col-lg-12 col-md-12 col-sm-12 text-center">
              <p>Search your Real State Agency or select it at the map below</p>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
              <div class="searchDiv"> <i class="fa fa-search" aria-hidden="true"></i>
                <input class="searchBox" type="text" placeholder="Search..">
              </div>
            </div>
          </div>
          <div class="mapDiv m-t-10">
            <div class="row">
              <div class="col-lg-12 col-lg-12 col-md-12 col-sm-12">
                <?=$options['map'];?>
              </div>
            </div>
          </div>
          <div class="row m-t-10">
            <div class="col-lg-12 col-md-12 col-sm-12 text-center">
              <p>Select radius where you want to get more propeties</p>
            </div>
          </div>
          <div class="rangeDiv">
            <div class="range-wrap">
              <div class="range-value top-30" id="radiusVal"></div>
              <input name="radius" id="radius" type="range" min="1" max="100" value="20" step="1">
              <div class="row m-t-10">
                <div class="left textLeft">
                  <p id="rangeminVlaue">0</p>
                </div>
                <div class="right textRight">
                  <p class="rangemaxVlaue">100KM</p>
                </div>
              </div>
            </div>
            <button type="button" class="m-t-10 commonBtn next">Next</button>
          </div>
        </section>
        <section class="tab hide" id="step2">
          <div class="row">
            <div class="col-lg-3 p-t-8 text-center"> <a class="commonBtn prev" id="step2prev" href="javascript:void(0)">Back</a> </div>
            <div class="col-lg-6 text-center">
              <h3 id="stepValue">STEP 2/3</h3>
            </div>
            <div class="col-lg-3 p-t-8"> <a class="commonBtn next" id="step2next" href="javascript:void(0)">Next</a> </div>
          </div>
            <div class="row m-t-20"></div>
          <div class="row m-t-20">
            <div class="col-lg-12">
              <div id="bar" class="progress progressWidth">
                <div class="progress-bar bg-info" role="progressbar" style="width: 66.3%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
          </div>
          <div class="row m-t-20">
            <div class="col-lg-12">
              <p>How many property leads would you like to get every month?</p>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-12"> <img src="<?=plugin_dir_url( __FILE__ )?>assets/download.png"> </div>
          </div>
          <div class="rangeDiv">
            <div class="range-wrap">
              <div class="range-value top-30" id="leadsVal"></div>
              <input id="leads" name="leads" type="range" min="1" max="100" value="15" step="1">
              
              <div class="row m-t-10">
                <div class="left textLeft">
                  <p id="minVlaue">0</p>
                </div>
                <div class="right textRight">
                  <p class="maxVlaue">100</p>
                </div>
              </div>
            </div>
            <button class="m-t-10 commonBtn next" type="button">Next</button>
          </div>
        </section>
        <section class="tab hide" id="step3">
<div class="row">
            <div class="col-lg-3 col-md-12 col-sm-12 p-t-8 text-center"> <a class="commonBtn prev" id="step2prev" href="javascript:void(0)">Back</a> </div>
            <div class="col-lg-6 col-md-12 col-sm-12 text-center">
              <h3 id="stepValue">STEP 3/3</h3>
            </div>
            <!--<div class="col-lg-3 p-t-8"> <a class="commonBtn next" id="step2next" href="javascript:void(0)">Next</a> </div>-->
          </div>
<div class="row m-t-20">
            <div class="col-lg-12 col-md-12 col-sm-12 ">
              <div id="bar" class="progress progressWidth">
                <div class="progress-bar bg-info" role="progressbar" style="width: 100%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
          </div>
<div class="row">
<div id="resp" class="col-md-12 col-md-12 col-sm-12 "></div>
</div>
        <div class="row">
          <div class="col-lg-12 m-t-10 col-md-12 col-sm-12 ">
            <h4>Introduce your data to discover your monthly price:</h4>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 ">
            <div class="formDiv">
              <div class="inputDiv">
                <div class="row">
                  <div class="col-md-4 col-md-4 col-sm-12"> <label class="label" for="name">Name:</label> </div>
                  <div class="col-md-8 col-md-8 col-sm-12"> 
                    <input type="text" name="name" id="name" class="form-control">
                    <span id="resp_name"></span>
                  </div>
                </div>
              </div>
              <div class="inputDiv">
                <div class="row">
                  <div class="col-md-4 col-md-4 col-sm-12"> <label class="label" for="agency">Agency:</label> </div>
                  <div class="col-md-8 col-md-8 col-sm-12">
                    <input type="text" name="agency" id="agency" class="form-control">
                    <span id="resp_agency"></span>
                  </div>
                </div>
              </div>
              <div class="inputDiv">
                <div class="row">
                  <div class="col-md-4 col-md-4 col-sm-12"> <label class="label" for="agency">email:</label> </div>
                  <div class="col-md-8 col-md-8 col-sm-12">
                    <input type="email" id="email" name="email" class="form-control">
                    <span id="resp_email"></span>
                  </div>
                </div>
              </div>
              <div class="inputDiv">
                <div class="row">
                  <div class="col-md-4 col-md-4 col-sm-12"> <label class="label" for="phone">phone:</label> </div>
                  <div class="col-md-8 col-md-8 col-sm-12">
                    <input type="text" name="phone" id="phone" class="form-control">
                    <span id="resp_phone"></span>
                  </div>
                </div>
              </div>
              <div class="inputDiv">
                <div class="row">
                  <div class="col-md-4 col-md-4 col-sm-12"><label class="label" for="password">password:</label> </div>
                  <div class="col-md-8 col-md-8 col-sm-12">
                    <input type="password" name="password" id="password" class="form-control">
                    <span id="resp_password"></span>
                  </div>
                </div>
              </div>
              <div class="inputDiv">
                <div class="row">
                  <div class="col-md-4 col-md-4 col-sm-12"> <label class="label" for="terms">terms:</label> </div>
                  <div class="col-md-8 col-md-8 col-sm-12">
                    <label style="float: left;line-height: 60px;">
<input type="checkbox" id="terms" name="terms" value="Yes" style="top: 10px;position: absolute;right: 90%;width: 18px;height: 18px;"/>
                    <span style="float: left;line-height: 40px;position: absolute;top: 0;left: 15%;">I Accept</span></label> 
                    <span id="resp_terms"></span>
                  </div>
                </div>
              </div>
              <!--<button type="submit" name="sbtn" class="commonBtn" id="Sbtn">Discover my Price</button>-->
              <button type="button" class="commonBtn" id="discoverPrice">Discover my Price</button>
            </div>
          </div>
        </div>      
        </section>
          
<section class="tab hide" id="step4">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 m-t-10">
            <h4>Congratulations, you may get up to <span class="total-leads"></span> for only:</h4>
            <input type="hidden" name="leadPrice" value="" id="leadPrice"/>
            <input type="hidden" name="totalLeads" value="" id="totalLeads"/>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 m-t-10">
            <p id="priceOutput"><span>200</span>€/Month</p>
            <button class="startNowBtn" type="button" name="submit" id="Sbtn">START NOW</button>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 m-t-10">
            <p>Modify radius if you want to adjust the price:</p>
        </div>
    </div>
    <div class="rangeDiv row">
        <div class="range-wrap col-lg-12 col-md-12 col-sm-12">
              <div class="range-value top-30" id="radiusVal-b"></div>
              <input id="radius-b" name="radius-b" type="range" min="1" max="100" value="20" step="1">
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 m-t-10">
            <p>Modify number of leads you want to recieve monthly:</p>
        </div>
    </div>
    <div class="rangeDiv row">
        <div class="range-wrap col-lg-12 col-md-12 col-sm-12">
            <div class="range-value top-30" id="leadsVal-b"></div>
            <input id="leads-b" name="leads-b" type="range" min="1" max="100" value="15" step="1">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 textLeft">
                    <!--<p id="montlyMin"></p>-->
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 textRight">
                    <!--<p id="montlyMin">100</p>-->
                </div>
            </div>
        </div>
    </div>
</section>
          <!--QUESTIONS-->
          <?php include('questions.php');?>
      </div>
    </div>
  </div>
</form>
</section>
<div id="processing"></div>
<pre>
<?php 

print_r ($_POST);
echo '</pre>';
//die();
 $user = get_user_by( 'email', $_POST['theEmail'] );
$user_id = $user->ID;
// print_r($_POST['email']);   

for ($x = 1; $x < 100; $x++) {
    if($_POST["question$x"] != ""){
    update_user_meta( $user_id, "question".$x, $_POST["question$x"]); 
    }
}
 
/*=LOGIN=*/
function auto_login_new_user( $user_id ) {
    wp_set_current_user($user_id);
    wp_set_auth_cookie($user_id);
    $user = get_user_by( 'id', $user_id );
    do_action( 'wp_login', $user->user_login );
    wp_redirect( home_url() ); 
    exit;
}
add_action( 'user_register', 'auto_login_new_user' ); 

?>    
<?php $_SESSION['user_email'] = $_POST['email'] ?>
<!--<pre id="test"></pre>-->
<?php $dir = plugin_dir_path(__DIR__); ?>
  
<script>
function uploadFile(btn,upl,valSend,upl_resp){
	
	$("#"+btn).click(function(){

   var fd = new FormData();

   var files = $('#'+upl)[0].files[0];

   fd.append('file',files);

   $.ajax({
       url:'<?=plugin_dir_url( __FILE__ )."/upload.php";?>',
       type:'post',
//       dataType : 'json',
       data:fd,
       contentType: false,
       processData: false,
           beforeSend: function() {
              $('.'+upl_resp).html('Uploading, please wait...');
           },
       success:function(response){
           if(response != 0){
               $("#"+valSend).attr("value",response); 
               $('.'+upl_resp).html('Uploaded successfully.').removeClass('text-danger').addClass('text-success');
           }else{
                $('.'+upl_resp).html('No file was uploaded,\n\
<br>Please not that only these formats are allowed: .pdf,.doc,docx,jpg,png,jpeg<br>\n\
And maximum file size should be less than 4MB.');
            $('#'+upl).click(function(){ $('.'+upl_resp).empty(); });
           }
       }
   });
   
});
}//ends upl

function leadPriceCalc(value){
	if(value <= 2){
                pricePM = <?=$options['lead1'];?> * $('#leads-b').val();
		$('#priceOutput span').text(pricePM); 
		$('#leadPrice').val(pricePM);   
	} 
	else if(value <= 5){
                pricePM = <?=$options['lead2'];?> * $('#leads-b').val();
		$('#priceOutput span').text(pricePM); 
		$('#leadPrice').val(pricePM);    
	} else if(value <= 10){
                pricePM = <?=$options['lead3'];?> * $('#leads-b').val();
		$('#priceOutput span').text(pricePM); 
		$('#leadPrice').val(pricePM);   
	}else if(value <= 25){
                pricePM = <?=$options['lead4'];?> * $('#leads-b').val();
		$('#priceOutput span').text(pricePM); 
		$('#leadPrice').val(pricePM);   
	}else if(value <= 50){
                pricePM = <?=$options['lead5'];?> * $('#leads-b').val();
		$('#priceOutput span').text(pricePM); 
		$('#leadPrice').val(pricePM);  
	}else if(value <= 100){
                pricePM = <?=$options['lead6'];?> * $('#leads-b').val();
		$('#priceOutput span').text(pricePM); 
		$('#leadPrice').val(pricePM);  
	}
}
$(document).ready(function(){
$('#val_question7_2').hide();
$('#val_question7_2').css("display","none");
	  /*==|LEADS & PRICES|==*/
$("#radiusVal").text($("#radius").val()+' KM');
$("#leadsVal").text($("#leads").val()+' Leads');

$("#radiusVal-b").text($("#radius-b").val()+' KM');
$("#leadsVal-b").text($("#leads-b").val()+' Leads');



$('#email').change( function() {
  $('#theEmail').val($(this).val());
});
  /*==|FIRST VALUES|==*/ 	
        $("#radius").mousemove(function () {
           $("#radiusVal").text($("#radius").val()+' KM');
		   $('#radius-b').val( $("#radius").val() );  //first value, can later modify
		   $("#radiusVal-b").text($("#radius").val()+' KM');// display only
		   		//==onChange Displ Cond
				leadPriceCalc($(this).val());
       }); 
        $("#leads").mousemove(function () {
           $("#leadsVal").text($("#leads").val()+' Leads');
		   $('#leads-b').val( $("#leads").val() );  //first value, can later modify
		   $("#leadsVal-b").text($("#leads").val()+' Leads');// display only
		   //==onChange Displ
           $(".total-leads").text($("#leads-b").val()+' Leads');
           $("#totalLeads").val($("#leads-b").val());
           leadPriceCalc($("#radius").val());
       });
        
  /*==|MODIFIED VALUES|==*/         
        $("#radius-b").mousemove(function () {
           $("#radiusVal-b").text($("#radius-b").val()+' KM');
		   //==onChange Displ Cond
			leadPriceCalc($(this).val());
       		}); 
        $("#leads-b").mousemove(function () {
           $("#leadsVal-b").text($("#leads-b").val()+' Leads');
		   //==onChange Displ
           $(".total-leads").text($("#leads-b").val()+' Leads');
           $("#totalLeads").val($("#leads-b").val());
         leadPriceCalc($("#radius-b").val());
       }); 
	   
	            
 /*==|STEPS|==*/           
            $('#step1 .next').click(function(){
                $('#step1').addClass('hide');
                $('#step2').addClass('show');
                $('#step2').removeClass('hide');
                    $('html, body').animate({
                    scrollTop: $("#step2").offset().top
                    }, 1000);
            });
            
            $('#step2 .prev').click(function(){
                $('#step2').addClass('hide');
                $('#step2').removeClass('show');
                $('#step1').addClass('show');
                $('#step1').removeClass('hide');
            });
                   
            $('#step2 .next').click(function(){
                $('#step2').addClass('hide');
                $('#step3').addClass('show');
                $('#step3').removeClass('hide');
                    $('html, body').animate({
                    scrollTop: $("#step3").offset().top
                    }, 1000);
            });
            
            $('#step3 .prev').click(function(){
                $('#step3').addClass('hide');
                $('#step3').removeClass('show');
                $('#step2').addClass('show');
                $('#step2').removeClass('hide');
            });
// prevent form submition on enter
  $(window).keydown(function(event){
    if(event.keyCode == 13) {
      event.preventDefault();
      return false;
    }
  });			
             //add remove errors on keychange      
            $('#name').keyup(function(){
				$('#resp_name').html('');
				$('#resp_name').removeClass('text-danger');
			});     
            $('#agency').keyup(function(){
				$('#resp_agency').html('');
				$('#resp_agency').removeClass('text-danger');
			});    
            $('#email').keyup(function(){
				$('#resp_email').html('');
				$('#resp_email').removeClass('text-danger');
			});
            $('#phone').keyup(function(){
				$('#resp_phone').html('');
				$('#resp_phone').removeClass('text-danger');
			});
            $('#password').keyup(function(){
				$('#resp_password').html('');
				$('#resp_password').removeClass('text-danger');
			});
            $('#terms').click(function(){
				$('#resp_terms').html('');
				$('#resp_terms').removeClass('text-danger');
			});
		
			  // validation before send    
            $('#discoverPrice').click(function(){
		
		
				
	    //CHECK EMPT VAL
	    if($('#name').val() == ""){
                $('html, body').animate({
                scrollTop: $("#resp").offset().top
                }, 1000);
                $('#resp_name').html('Please provide your full name.');
                $('#resp_name').addClass('text-danger');
				$('#name').focus();
                return false;
            } else if($('#agency').val() == ""){
                $('html, body').animate({
                scrollTop: $("#hb-user").offset().top
                }, 1000);
                $('#resp_agency').html('Please provide your agency.');
                $('#resp_agency').addClass('text-danger');
				$('#agency').focus();
                return false;
            } else if($('#email').val() == ""){
                $('html, body').animate({
                scrollTop: $("#hb-user").offset().top
                }, 1000);
                $('#resp_email').html('Please provide your email.');
                $('#resp_email').addClass('text-danger');
				$('#email').focus();
                return false;
            } else if($('#phone').val() == ""){
                $('html, body').animate({
                scrollTop: $("#hb-user").offset().top
                }, 1000);
                $('#resp_phone').html('Please provide your phone.');
                $('#resp_phone').addClass('text-danger');
				$('#phone').focus();
                return false;
            }else if($('#password').val() == ""){
 
                $('#resp_password').html('Please provide your password.');
                $('#resp_password').addClass('text-danger');
				$('#password').focus();
                return false;
            }else if($('#terms').prop("checked") == false){
 
                $('#resp_terms').html('You must accept the terms.');
                $('#resp_terms').addClass('text-danger');
                return false;
            } else{  
		//SHOW FINAL
                $('#step3').addClass('hide');
                $('#step4').addClass('show');
                $('#step4').removeClass('hide');
                
                    $('html, body').animate({
                    scrollTop: $("#hb-user").offset().top
                    }, 1000);
			}
            });
//   $('#email').click(function(){
//       
//   }); 
  /*==|AJAX|==*/                
            $("#Sbtn").click(function(e) { 
                $.ajax({url: '<?=plugin_dir_url( __FILE__ )?>submit.php',  
                    type: 'POST',
                    data:$("form").serialize(),                   
                        success: function(result) { 
//                    $("#test").html(result); 

 if(result == '1'){ 
     $('#hb-user')[0].reset(); $('#hb-user').find('#submit').prop('disabled', true);
//     window.location.replace("<?=site_url();?>/cart");
//     window.location = "<?=site_url();?>/mi-cuenta/";
 /*==|QUESTIONS init|==*/           
          
                $('#step4').addClass('hide');
                $('#step4').removeClass('show');
                $('#q1').addClass('show');
                $('#q1').removeClass('hide');
  }
//else{ console.log('error adding product into woo commerce!');}

                }//success
            }); //ends ajax
            }); //ends Sbtn click
          
  <?php for ($x = 1; $x <= $total_questions; $x++) {?>   

$('#val_question<?=$x?>').change( function() {
        
    $('#question<?=$x?>').val($(this).val());
 
});
            /*QUESTIONS PREVIOUS added later!*/
            $('#q<?=$x?> .prev').click(function(){
                $('#q<?=$x?>').addClass('hide');
                $('#q<?=$x?>').removeClass('show');
                $('#q<?=$x-1?>').addClass('show');
                $('#q<?=$x-1?>').removeClass('hide');
            });
 

$('.checkboxMulti').change( function() {
            
        var q_arr = [];                  
            $.each($("input[name='val_question<?=$x?>[]']:checked"), function(){
                 console.log($(this).val());
                q_arr.push($(this).val());
            });
//            debugger;
//            console.log(q_arr.join(", "));
            $('#question<?=$x?>').val(q_arr.join(", "));
            

});//ends checkboxMulti
            $('#question<?=$x?>_other').change(function(){
                //q_arr.push('#question<?=$x?>_other');
                $('#question<?=$x?>').val($('#question<?=$x?>').val()+", Other: "+$(this).val());
            });// ends keyup
           
           
//uploadFile(btn,uplFile,valSend,upl_resp);

uploadFile('upl_btn<?=$x?>_1','file_upload<?=$x?>_1','question<?=$x?>','upl_resp');
uploadFile('upl_btn<?=$x?>_2','file_upload<?=$x?>_2','question<?=$x?>','upl_resp');
uploadFile('upl_btn<?=$x?>_3','file_upload<?=$x?>_3','question<?=$x?>','upl_resp');

$('#val_question<?=$x?>_no').click(function(){
     console.log($(this).val());
     $('#question<?=$x?>').val($(this).val());
});
$('#val_cond_question<?=$x?>').keyup(function(){
     console.log($(this).val());
      $('#question<?=$x?>').val('Yes, '+$(this).val());
});
            $('#q<?=$x?> .next').click(function(){
            
                $('#q<?=$x?>').addClass('hide');
                $('#q<?=$x?>').removeClass('show');
            <?php if($x == $total_questions){/* TOTAL REACHED*/}else{?>     
                $('#q<?=$x+1?>').addClass('show');
                $('#q<?=$x+1?>').removeClass('hide');
            <?php }?>
   
    /*SENDING THIS VALUE TO DATABASE*/
                    /*var seializedTwoFields = $('#theEmail,#question<?=$x;?>').serialize();
                        console.log(seializedTwoFields);
                        $.ajax({url: '<?=plugin_dir_url( __FILE__ )?>submitQ.php',  
                        type: 'POST',
                        data:seializedTwoFields, 
                        success: function(result) { console.log('saved!');
    <?php /* if($x == $total_questions){?> window.location.href="<?= site_url().'/cart';?>";<?php } */?>
    <?php //if($x == $total_questions){?> window.location.href="<?php //site_url().'/mi-cuenta';?>";<?php // }?>
                        }
                        });*/
            });
<?php }?> 
$('#final').click(function(){
    
});
    });//ends doc ready
 </script> 
<?php
    return ob_get_clean();
}
//endfunct 
add_shortcode('headblue_form', 'hb_lead_form');