<?php /*Template: submitQ*/ require('./../../../wp-load.php'); ?><?php
print_r ($_POST);

//die();
 $user = get_user_by( 'email', $_POST['theEmail'] );
$user_id = $user->ID;
// print_r($_POST['email']);   

for ($x = 1; $x < 100; $x++) {
    if($_POST["question$x"] != ""){
    update_user_meta( $user_id, "question".$x, $_POST["question$x"]); 
    }
}
 
/*=LOGIN=*/
function auto_login_new_user( $user_id ) {
    wp_set_current_user($user_id);
    wp_set_auth_cookie($user_id);
    $user = get_user_by( 'id', $user_id );
    do_action( 'wp_login', $user->user_login );
    wp_redirect( home_url() ); 
    exit;
}
add_action( 'user_register', 'auto_login_new_user' ); 
