<?php

$name = $_POST['name'];
$range = $_POST['range'];
$lessrange = $_POST['lessrange'];
$agency = $_POST['agency'];
$email_user = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];
$terms = $_POST['terms'];
$leadPrice = $_POST['leadPrice'];
function headblue_user_profile_fields($user) { ?>

<h3>
  <?php _e("HeadBlue Business information", "blank"); ?>
</h3>
<style>
tr.user-url-wrap {    display: none;}
</style>
<table class="form-table">
  <!--<tr><th colspan="2"><h3>User</h3></th></tr>-->
  <tr>
    <th><label for="name">
        <?php _e("Name"); ?>
      </label></th>
    <td><input type="text" name="name" id="name" value="<?php echo esc_attr(get_the_author_meta('name', $user->ID)); ?>" class="regular-text" />
      <br />
      
      <!--<span class="description"><?php // _e("Please enter your name."); ?></span>--></td>
  </tr>
  <tr>
    <th><label for="agency">
        <?php _e("Agency"); ?>
      </label></th>
    <td><input type="text" name="agency" id="agency" value="<?php echo esc_attr(get_the_author_meta('agency', $user->ID)); ?>" class="regular-text" />
      <br /></td>
  </tr>
  <tr>
    <th><label for="phone">
        <?php _e("Phone"); ?>
      </label></th>
    <td><input type="text" name="phone" id="phone" value="<?php echo esc_attr(get_the_author_meta('phone', $user->ID)); ?>" class="regular-text" />
      <br /></td>
  </tr>
  <tr>
    <th><label for="phone">
        <?php _e("Lead Price Per Month"); ?>
      </label></th>
    <td><input type="text" name="leadPrice" id="leadPrice" value="<?php echo esc_attr(get_the_author_meta('leadPrice', $user->ID)); ?>" class="regular-text" />
      <br /></td>
  </tr>
  <tr>
    <th><label for="range">
        <?php _e("Total Leads"); ?>
      </label></th>
    <td><input type="text" name="totalLeads" id="totalLeads" value="<?php echo esc_attr(get_the_author_meta('totalLeads', $user->ID)); ?>" class="regular-text" />
      <br /></td>
  </tr>
</table>
<h3>
  <?php _e("Answered Questions", "blank"); ?>
</h3>
<table class="form-table">
    <?php
    $qn=1;
    //$query = new WP_Query(array('post_type' => 'questions', 'author' => $authorID));
    $query = new WP_Query(array('post_type' => 'questions', 'author' => $authorID, "orderby" => 'meta_value_num',"meta_key" => 'question_number',"order" => 'ASC'));?>
	<?php if($query->have_posts()): ?>
<?php while ( $query->have_posts() ) : $query->the_post();?>
<?php  $questions = $query->posts; ?>
<?php  $total_questions = count($questions);?>
<tr>
    <th><label for="range">
      <?= the_title(); ?>
    </label></th>
    <td><?php $qst = get_the_author_meta('question'.$qn, $user->ID); if(filter_var($qst, FILTER_VALIDATE_URL)){
        echo "<a href='".$qst."' target='_blank'>Uploaded File</a>";
    }else{ echo $qst;}  ?></td>
</tr>
<?php $qn++;?>
<?php endwhile; ?>
<?php endif; ?>
</table>
<?php
}

add_action('show_user_profile', 'headblue_user_profile_fields');
add_action('edit_user_profile', 'headblue_user_profile_fields');

// saving extra fields details in database:

function save_headblue_user_profile_fields($user_id) {
    if (!current_user_can('edit_user', $user_id)) {
        return false;
    }
    update_user_meta($user_id, 'name', $_POST['name']);
    update_user_meta($user_id, 'range', $_POST['range']);

    update_user_meta($user_id, 'agency', $_POST['agency']);
    update_user_meta($user_id, 'email', $_POST['email']);
    update_user_meta($user_id, 'phone', $_POST['phone']);
    update_user_meta($user_id, 'leadPrice', $_POST['leadPrice']);
    update_user_meta($user_id, 'totalLeads', $_POST['totalLeads']);

}

add_action('personal_options_update', 'save_ntibn_user_profile_fields');
add_action('edit_user_profile_update', 'save_ntibn_user_profile_fields');
?>
