<?php
class HbSettingsPage
{
    
    /*******
     * Holds the values to be used in the fields callbacks
     *********/
  public $options;
  //PAGE AND MENU SETTINGS:
  public $page_slug = 'hb-setting-admin';
  public $page_title = 'Head Blue Settings';
  public $menu_title = 'Head Blue Settings';
  public $menu_icon = '';
  public $menu_position = 12;
  
  
  //CUSTOM SETTINGS ITEMS:  
  public $section_title = '';//THIS IS OPTIONAL, APPEATS RIGHT ABOVE THE FIELDS AS A HEADING//section_info
  public $section_info = '';//THIS IS OPTIONAL, APPEATS RIGHT ABOVE THE FIELDS AS A PARAGRAPHP INFO TEXT//
  public $option_group = 'my_option_group';
  public $option_name = 'hb_options';
  public $field_sectionid = 'setting_section_id';
  
     public $fields_arr = [
        ['name'=>'map','title'=>'Map','type'=>'textarea'],
         
//        ['name'=>'range','title'=>'Range'],

        ['name'=>'lead1','title'=>'Lead fee (0-2KM)'],
        ['name'=>'lead2','title'=>'Lead fee (2-5KM)'],
        ['name'=>'lead3','title'=>'Lead fee (5-10KM)'],
        ['name'=>'lead4','title'=>'Lead fee (10-25KM)'],
        ['name'=>'lead5','title'=>'Lead fee (25-50KM)'],
        ['name'=>'lead6','title'=>'Lead fee (50-100KM)'],
         
        ['name'=>'leadprod1','title'=>'Lead 1 Product Association'],
        ['name'=>'leadprod2','title'=>'Lead 2 Product Association'],
        ['name'=>'leadprod3','title'=>'Lead 3 Product Association'],
        ['name'=>'leadprod4','title'=>'Lead 4 Product Association'],
        ['name'=>'leadprod5','title'=>'Lead 5 Product Association'],
        ['name'=>'leadprod6','title'=>'Lead 6 Product Association'],
         
         
        ['name'=>'hb_step','title'=>'Step(Paso)'],
        ['name'=>'next','title'=>'Next text'],
        ['name'=>'back','title'=>'Back text'],
        ['name'=>'before_search_text','title'=>'Before search text'],
        ['name'=>'before_radius_text','title'=>'Before radius text'],
        ['name'=>'leads_text','title'=>'Leads text on step 2'],
        ['name'=>'lead','title'=>'Lead'],
        ['name'=>'step2_image','title'=>'Step2 image (Paso 2 imagen)'],
        ['name'=>'step3_heading','title'=>'Step3 heading (Paso 3 encabezado)'],
        ['name'=>'step3_formbutton','title'=>'Step3 form button (Paso 3)'],
        ['name'=>'leads_text_step4','title'=>'Leads text step4 (Paso 4)'],
        ['name'=>'startnow_btn','title'=>'Start-now button'],
        ['name'=>'modifyradius_text','title'=>'Modify radius text'],
        ['name'=>'modifyleads_text','title'=>'Modify leads text'],
        ['name'=>'quiz_init','title'=>'Quiz start text'],
        ['name'=>'lastbtn_text','title'=>'Last button text'],
         
         

    ];
    function map_callback() {
         $val = isset( $this->options['map'] ) ? esc_attr( $this->options['map']) : '';
            $this->textarea("$this->option_name[map]", "map", $val);
    }
    function range_callback() {
         $val = isset( $this->options['range'] ) ? esc_attr( $this->options['range']) : '';
//            $this->text("$this->option_name[range]", "range", $val);
         select_wpquery("$this->option_name[range]", $id, $dbval = null, $req = null, $desc = null,$wpquery,$key,$value, $css_class = null);
    }
    function lead1_callback() {
         $val = isset( $this->options['lead1'] ) ? esc_attr( $this->options['lead1']) : '';
            $this->text("$this->option_name[lead1]", "lead1", $val,'','float lead','in €');
    }
    function lead2_callback() {
         $val = isset( $this->options['lead2'] ) ? esc_attr( $this->options['lead2']) : '';
            $this->text("$this->option_name[lead2]", "lead2", $val,'','float lead','in €');
    }
    function lead3_callback() {
         $val = isset( $this->options['lead3'] ) ? esc_attr( $this->options['lead3']) : '';
            $this->text("$this->option_name[lead3]", "lead3", $val,'','float lead','in €');
    }
    function lead4_callback() {
         $val = isset( $this->options['lead4'] ) ? esc_attr( $this->options['lead4']) : '';
            $this->text("$this->option_name[lead4]", "lead4", $val,'','float lead','in €');
    }
    function lead5_callback() {
         $val = isset( $this->options['lead5'] ) ? esc_attr( $this->options['lead5']) : '';
            $this->text("$this->option_name[lead5]", "lead5", $val,'','float lead','in €');
    }
    function lead6_callback() {
         $val = isset( $this->options['lead6'] ) ? esc_attr( $this->options['lead6']) : '';
            $this->text("$this->option_name[lead6]", "lead6", $val,'','float lead','in €');
    }
 
    function leadprod1_callback() {
            $query = new WP_Query( array( 'post_type' => 'product' ) );
            $products = $query->posts;
            $val = isset( $this->options['leadprod1'] ) ? esc_attr( $this->options['leadprod1']) : '';
            $this->select_wpquery("$this->option_name[leadprod1]", 'product', $val, $req, $desc, $products, 'ID', 'post_title', $css_class);
    }
    function leadprod2_callback() {
            $query = new WP_Query( array( 'post_type' => 'product' ) );
            $products = $query->posts;
            $val = isset( $this->options['leadprod2'] ) ? esc_attr( $this->options['leadprod2']) : '';
            $this->select_wpquery("$this->option_name[leadprod2]", 'product', $val, $req, $desc, $products, 'ID', 'post_title', $css_class);
    }
    function leadprod3_callback() {
            $query = new WP_Query( array( 'post_type' => 'product' ) );
            $products = $query->posts;
            $val = isset( $this->options['leadprod3'] ) ? esc_attr( $this->options['leadprod3']) : '';
            $this->select_wpquery("$this->option_name[leadprod3]", 'product', $val, $req, $desc, $products, 'ID', 'post_title', $css_class);
    }
    function leadprod4_callback() {
            $query = new WP_Query( array( 'post_type' => 'product' ) );
            $products = $query->posts;
            $val = isset( $this->options['leadprod4'] ) ? esc_attr( $this->options['leadprod4']) : '';
            $this->select_wpquery("$this->option_name[leadprod4]", 'product', $val, $req, $desc, $products, 'ID', 'post_title', $css_class);
    }
    function leadprod5_callback() {
            $query = new WP_Query( array( 'post_type' => 'product' ) );
            $products = $query->posts;
            $val = isset( $this->options['leadprod5'] ) ? esc_attr( $this->options['leadprod5']) : '';
            $this->select_wpquery("$this->option_name[leadprod5]", 'product', $val, $req, $desc, $products, 'ID', 'post_title', $css_class);
    }
    function leadprod6_callback() {
            $query = new WP_Query( array( 'post_type' => 'product' ) );
            $products = $query->posts;
            $val = isset( $this->options['leadprod6'] ) ? esc_attr( $this->options['leadprod6']) : '';
            $this->select_wpquery("$this->option_name[leadprod6]", 'product', $val, $req, $desc, $products, 'ID', 'post_title', $css_class);
    } 
    
    function hb_step_callback() {
         $val = isset( $this->options['hb_step'] ) ? esc_attr( $this->options['hb_step']) : '';
            $this->text("$this->option_name[hb_step]", "hb_step", $val,'','','');
    }
    
    function next_callback() {
         $val = isset( $this->options['next'] ) ? esc_attr( $this->options['next']) : '';
            $this->text("$this->option_name[next]", "next", $val,'','','');
    }
    
    function back_callback() {
         $val = isset( $this->options['back'] ) ? esc_attr( $this->options['back']) : '';
            $this->text("$this->option_name[back]", "back", $val,'','','');
    }
    
    function before_search_text_callback() {
         $val = isset( $this->options['before_search_text'] ) ? esc_attr( $this->options['before_search_text']) : '';
            $this->textarea("$this->option_name[before_search_text]", "before_search_text", $val,'','','');
    }
    
    function before_radius_text_callback() {
         $val = isset( $this->options['before_radius_text'] ) ? esc_attr( $this->options['before_radius_text']) : '';
            $this->textarea("$this->option_name[before_radius_text]", "before_radius_text", $val,'','','');
    }
    
    function leads_text_callback() {
         $val = isset( $this->options['leads_text'] ) ? esc_attr( $this->options['leads_text']) : '';
            $this->textarea("$this->option_name[leads_text]", "leads_text", $val,'','','');
    }
    
    function lead_callback() {
         $val = isset( $this->options['lead'] ) ? esc_attr( $this->options['lead']) : '';
            $this->text("$this->option_name[lead]", "lead", $val,'','','');
    }
    
    function step2_image_callback() {
         $val = isset( $this->options['step2_image'] ) ? esc_attr( $this->options['step2_image']) : '';
            $this->wp_upl("$this->option_name[step2_image]", "step2_image", $val,'','','');
    }
    function step3_heading_callback() {
         $val = isset( $this->options['step3_heading'] ) ? esc_attr( $this->options['step3_heading']) : '';
            $this->textarea("$this->option_name[step3_heading]", "step3_heading", $val,'','','');
    }
    function step3_formbutton_callback() {
         $val = isset( $this->options['step3_formbutton'] ) ? esc_attr( $this->options['step3_formbutton']) : '';
            $this->text("$this->option_name[step3_formbutton]", "step3_formbutton", $val,'','','');
    }
    function leads_text_step4_callback() {
         $val = isset( $this->options['leads_text_step4'] ) ? esc_attr( $this->options['leads_text_step4']) : '';
            $this->textarea("$this->option_name[leads_text_step4]", "leads_text_step4", $val,'','','');
    }
    function startnow_btn_callback() {
         $val = isset( $this->options['startnow_btn'] ) ? esc_attr( $this->options['startnow_btn']) : '';
            $this->text("$this->option_name[startnow_btn]", "startnow_btn", $val,'','','');
    }
    function modifyradius_text_callback() {
         $val = isset( $this->options['modifyradius_text'] ) ? esc_attr( $this->options['modifyradius_text']) : '';
            $this->textarea("$this->option_name[modifyradius_text]", "modifyradius_text", $val,'','','');
    }
    function modifyleads_text_callback() {
         $val = isset( $this->options['modifyleads_text'] ) ? esc_attr( $this->options['modifyleads_text']) : '';
            $this->textarea("$this->option_name[modifyleads_text]", "modifyleads_text", $val,'','','');
    }
    function quiz_init_callback() {
         $val = isset( $this->options['quiz_init'] ) ? esc_attr( $this->options['quiz_init']) : '';
            $this->textarea("$this->option_name[quiz_init]", "quiz_init", $val,'','','');
    }
    function lastbtn_text_callback() {
         $val = isset( $this->options['lastbtn_text'] ) ? esc_attr( $this->options['lastbtn_text']) : '';
            $this->text("$this->option_name[lastbtn_text]", "lastbtn_text", $val,'','','');
    }
    
    /**
     * Start up
     */
    public function __construct(){
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
    }

    /**
     * Add options page
     */
    public function add_plugin_page()
    {
        // This page
//        add_menu_page($page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position)
        add_menu_page(
            $this->page_title, 
            $this->menu_title, 
            'manage_options', 
            $this->page_slug, 
            array( $this, 'create_admin_page' ),
            $this->menu_icon,
            $this->menu_position   
        );
    }

    /**
     * Options page callback
     */
    public function create_admin_page()
    {
       
       include('admin_page.php');
    }
//---------------=====================================================-----------------\\

    /*************************
     * Register and add settings
     ***************************/
    public function page_init()
    {        
        register_setting(
            $this->option_group, // Option group
            $this->option_name, // Option name
            array( $this, 'sanitize' ) // Sanitize
        );

        add_settings_section(
            $this->field_sectionid, // ID
            (isset($this->section_title)?$this->section_title:''), // Title
            array( $this, 'print_section_info' ), // Callback
            $this->page_slug // Page
        );  
       
       foreach($this->fields_arr as $field){  
         add_settings_field(//===================================================
            $field['name'], 
            "<label for='".$field['name']."'>".$field['title']."</label>", 
            array( $this, $field['name'].'_callback' ), 
            $this->page_slug, 
            $this->field_sectionid
        );  
       }

       

//        add_settings_field($id, $title, $callback, $page, $section, $args)
    }

    /**
     * Sanitize each setting field as needed
     *
     * @param array $input Contains all settings fields as array keys
     */
    public function sanitize( $input )
    {
        return $input;
    }

    /** 
     * Print the Section text
     */
    public function print_section_info()
    {
        echo (isset($this->section_info)?$this->section_info:'');
    }

    /** 
     * Get the settings option array and print one of its values
     */
    public function id_number_callback()
    {
        printf(
            '<input type="text" id="id_number" name="my_option_name[id_number]" value="%s" />',
            isset( $this->options['id_number'] ) ? esc_attr( $this->options['id_number']) : ''
        );
    }

    

/****
 * FORM FIELDS: 14
 * ***/    
       /********************|1.TEXT|**********************/
    public function text($name, $id, $dbval = null, $req = null,  $css_class = null,$desc = null) {?>  

              <input class="form-control <?=($css_class != ""?$css_class:'');?>" type="text" id="<?=$id?>" name="<?=$name?>" value="<?=($dbval != ""?$dbval:'');?>" <?=($req != ""?'required="required"':'');?>>
              <div class="desc"><?=$desc!=""?$desc:'';?></div>

<?php  }
/********************|2.TEXTAREA|**********************/
    public function textarea($name, $id, $dbval = null, $req = null, $css_class = null,$desc = null) {?>  

              <textarea class="form-control <?=($css_class != ""?$css_class:'');?>" id="<?=$id?>" name="<?=$name?>" <?=($req != ""?'required="required"':'');?>><?=($dbval != ""?$dbval:'');?></textarea>
              <div class="desc"><?=$desc!=""?$desc:'';?></div>

<?php  }
/********************|3.RADIO|**********************/
    public function radio($name, $id, $dbval = null, $req = null, $values=null, $css_class = null,$desc=null) {?>  
      
              <?php foreach($values as $value){?>
              <label> <?php $value_label = $this->clean($value);$value_label = ucfirst($value); echo $value_label;?>&nbsp;
              <input type="radio" value="<?=$value?>" <?=$value==$dbval?'checked="checked"':'';?>  class="<?=($css_class != ""?$css_class:'');?>" id="<?=$id?>" name="<?=$name?>" <?=($req != ""?'required="required"':'');?>/>
              </label>&nbsp;&nbsp;&nbsp;
              <?php }?>
              <div class="desc"><?=$desc!=""?$desc:'';?></div>
         
<?php  }
/********************|4.CHECKBOX|**********************/
    public function checkbox($name, $id, $dbval = null, $req = null, $value=null, $css_class = null,$desc = null) {?>  

              
              <label> <?php //$value_label = $this->clean($value);$value_label = ucfirst($value); echo $value_label;?>&nbsp;&nbsp;
              <input type="checkbox" value="<?=$value?>" <?=$value==$dbval?'checked="checked"':'';?>  class="<?=($css_class != ""?$css_class:'');?>" id="<?=$id?>" name="<?=$name?>" <?=($req != ""?'required="required"':'');?>/>
              </label>&nbsp;&nbsp;
              
              <div class="desc"><?=$desc!=""?$desc:'';?></div>
         
<?php  }
/********************|5.MULTISELECT|**********************/
    public function multiple($name, $id, $dbval = null, $req = null, $values, $css_class = null, $perLine = null,$desc=null) {?>  
 
              <style>.one{width:99%;}.two{width:49%;}.three{width:32%;}.four{width:24%;}.multi_val{display:inline-block;text-align:left;}</style>
             <?php 
                  switch ($perLine) {
                      case 1:
                        $perLine=  'one';
                          break;
                      case 2:
                        $perLine=  'two';
                          break;
                      case 3:
                        $perLine=  'three';
                          break;
                      case 4:
                        $perLine=  'four';
                          break;

                      default:
                        $perLine=  'one';
                          break;
                  }?>
              <?php foreach($values as $value){?>
              <label class="<?=$perLine;?> multi_val"> <?php $value_label = $this->clean($value);$value_label = ucfirst($value); echo sanitize_text_field($value_label);?>&nbsp;
                  <input type="checkbox" value="<?=$value?>" class="<?=($css_class != ""?$css_class:'');?>" name="<?=$name?>[]" <?=($req != ""?'required="required"':'');?> <?php if($dbval!=""){?><?php echo @in_array($value,$dbval)?'checked="checked"':'';?><?php }?>/>
              </label>
              <?php }?>
              <div class="desc"><?=$desc!=""?$desc:'';?></div>
          
<?php  }
//////
public function multiselect($name, $id, $dbval = null, $req = null, $values, $css_class = null,$desc=null) {?> 
    <select class="form-control <?=($css_class != ""?$css_class:'');?>" id="<?=$id?>" name="<?=$name?>[]" <?=($req != ""?'required="required"':'');?> multiple="multiple">
        <option value=''>Select</option>
          <?php  foreach ($values as $value) { //echo $dbval;?>
        <option value="<?=$value?>" <?php if($dbval!=""){?><?=@in_array($value,$dbval)?'selected="selected"':'';?><?php }?>><?= ucfirst($value);?></option>
    <?php  }?>  
    </select>
              <div class="desc"><?=$desc!=""?$desc:'';?></div>
    <?php }
    /********************|6.COUNTRIES|**********************/
    public function countries($name, $id, $dbval = null, $req = null,  $css_class = null,$desc = null) {?>  
      
              <?php $countries = array("Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Holy See (Vatican City State)", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan, Province of China", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe");
?> <select class="form-control <?=($css_class != ""?$css_class:'');?>" id="<?=$id?>" name="<?=$name?>" <?=($req != ""?'required="required"':'');?>>
    <option value=''>Select</option>
    <?php  foreach ($countries as $country) {?>
    <option value='<?=$country?>' <?=($country==$dbval)?"selected='selected'":'';?>><?= ucfirst($country);?></option>
    <?php  }?>
</select>
              <div class="desc"><?=$desc!=""?$desc:'';?></div>
         
<?php  }
/********************|7.DATE|**********************/
    public function dmy($id,$day,$month,$year, $db_day = null,$db_month = null,$db_year = null, $req = null, $desc = null, $css_class = null) {?>
        <?php if($dbval != ""){ /*$dt = $dbval; $date = date("d M Y", strtotime($dt));*/}?>
    
            <select name="<?=$day?>" id="<?=$day?>" class="day" <?=($req != ""?'required="required"':'');?>>  
  <?php if (!empty($db_day)) { ?><option value='<?= $db_day; ?>' selectd><?= $db_day; ?></option><?php } ?>       
                                            <option value=''>Day</option>
        <?php for ($d = 1; $d <= 31; $d++) {
            echo "<option value='$d'>$d</option>";
        } ?>
                                        </select>
                                        <select name="<?=$month?>" id="<?=$month?>" class="month" <?=($req != ""?'required="required"':'');?>>
                                            <?php if (!empty($db_month)) { ?><option value='<?= $db_month; ?>' selectd><?= $db_month; ?></option><?php } ?>
                                            <option value=''>Month</option>              
        <?php
        $months = array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');
        foreach ($months as $month) {
            echo "<option value='$month'>$month</option>";
        }
        ?>
                                        </select>

                                        <select name="<?=$year?>" id="<?=$year?>" class="year" <?=($req != ""?'required="required"':'');?>>
        
        <?php if (!empty($db_year)) { ?><option value='<?= $db_year; ?>' selectd><?= $db_year; ?></option><?php } ?>
                                            <option value=''>Year</option>
        <?php
        for ($y = 2018; $y >= 1970; $y--) {
            echo "<option value='$y'>$y</option>";
        }
        ?></select>
              <div class="desc"><?=$desc!=""?$desc:'';?></div>
          
<?php  }//ends date
/********************|8.FULLDATE|**********************/
    public function date($name, $id, $dbval = null, $req = null, $desc = null, $css_class = null) {?>
        <?php if($dbval != ""){$dt = $dbval;
        $date = date("d M Y", strtotime($dt));}?>
    
              <input class="form-control <?=($css_class != ""?$css_class:'');?>" type="text" id="<?=$id?>" name="<?=$name?>" value="<?=($dbval != ""?$date:'');?>" <?=($req != ""?'required="required"':'');?>>
              <div class="desc"><?=$desc!=""?$desc:'';?></div>
          
<script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <script>
(function($){
  //$('head').append('<script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript" />');
$('head').append('<link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />');


        $('#<?=$id?>').datepicker({
            uiLibrary: 'bootstrap4',
            format: 'dd mmm yyyy' 
        });

})(jQuery);
    </script>
<?php  }//ends date
/********************|9.SELECT|**********************/
public function select($name, $id, $dbval = null, $req = null, $desc = null,$options=null, $css_class = null) {?>  
      
 <select class="form-control <?=($css_class != ""?$css_class:'');?>" id="<?=$id?>" name="<?=$name?>" <?=($req != ""?'required="required"':'');?>>
    <option value=''>Select</option>
    <?php  foreach ($options as $option) {?>
    <option value='<?=$option?>' <?=($option==$dbval)?"selected='selected'":'';?>><?= ucfirst($option);?></option>
    <?php     }?>
</select>
              <div class="desc"><?=$desc!=""?$desc:'';?></div>
   
<?php  }
/********************|10.UPLOAD|**********************/
    public function upload($name, $id, $dbval = null, $req = null, $desc = null, $css_class = null, $val = null/*this'll be new value*/) {?>
      
              <input type="hidden" value="<?=($dbval!=""?$dbval:$val);?>" id="<?=$id?>" name="<?=$name?>" class="">
              <input class="<?=($css_class != ""?$css_class:'');?>" type="file" id="<?=$name?>_file" name="<?=$name?>_file" <?=($req != ""?'required="required"':'');?> accept="image/*" onChange="document.getElementById('<?=$name?>_img').src = window.URL.createObjectURL(this.files[0])"/>
              <button type="button" id="<?=$name?>_btn" class="btn btn-info btn-upload">Upload</button>
              <img src="<?=($dbval!=""?$dbval:'');?>" id="<?=$name?>_img" class="img-disp pull-right img-thumbnail" style="max-width:90px;"/>
              <div class="col-sm-12 text-danger" id="<?=$name?>_photo_resp"></div>
              <div class="desc"><?=$desc!=""?$desc:'';?></div>
   
<?php  }//ends simple upload field
/********************|11.WORDPRESS COLORPICKER|**********************/
    public function wp_color($name, $id, $dbval = null, $req = null, $desc = null, $css_class = null) {?>  
      <?php 
       wp_enqueue_style( 'wp-color-picker' );
      ?>
              <input class="form-control cpa-color-picker <?=($css_class != ""?$css_class:'');?>" type="text" id="<?=$id?>" name="<?=$name?>" value="<?=($dbval != ""?$dbval:'');?>" <?=($req != ""?'required="required"':'');?>>
              <div class="desc"><?=$desc!=""?$desc:'';?></div>
       <script>
        var $ = jQuery;
        jQuery(document).ready(function ($) {
            $(function() {
                $('.cpa-color-picker').wpColorPicker();
            });
        });
       </script>  
<?php  }
/********************|12.WORDPRESS UPLOADS|**********************/
    public function wp_upl($name, $id, $dbval = null, $desc = null, $css_class = null) {?>  
    <?php 
    wp_enqueue_media();
    wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');
    wp_enqueue_style('thickbox');
    ?>              
                    <input type="text" readonly name="<?=$name?>" id="<?=$id?>" value="<?= ($dbval  != "") ? ($dbval ) : ''; ?>" class="form-control col-sm-6" size="30" />
                    <input type="button" name="<?=$id?>" id="<?=$id?>-btn" class="btn btn-primary" value="Upload Image">
                    <div class="<?=$id?>_imagearea col-sm-3">
                        <div class="images_parent_class">
                            <div class="<?=$id?>-delete delete_btn">X</div>
                            <img src="<?= ($dbval  != "") ? ($dbval) : ''; ?>" id="<?=$id?>-img" class="<?= ($dbval  != "") ? 'img-thumbnail' : ''; ?>" style="margin-left: auto; margin-right: auto; display: block;"/>
                        </div>
                    </div>
            
              <div class="desc"><?=$desc!=""?$desc:'';?></div>
                          <script>
                var $ = jQuery;
                jQuery(document).ready(function ($) {
                    $("#<?=$id?>-btn").click(function (e) {
                        e.preventDefault();
                        var image = wp.media({
                            title: "Upload Image",
                            // mutiple: true if you want to upload multiple files at once
                            multiple: false
                        }).open()
                                .on("select", function (e) {
                                    // This will return the selected image from the Media Uploader, the result is an object
                                    var uploaded_image = image.state().get("selection").first();
                                    // We convert uploaded_image to a JSON object to make accessing it easier
                                    // Output to the console uploaded_image
                                    console.log(uploaded_image);
                                    var image_url = uploaded_image.toJSON().url;
                                    // Lets assign the url value to the input field
                                    $('#<?=$id?>').val(image_url);
                                    $('#<?=$id?>-img').attr('src', image_url);
                                    $('#<?=$id?>-img').addClass();
                                    $('.<?=$id?>-delete').show();
                                });
                    });
                });
                $(document).on('click', '.<?=$id?>-delete', function () {
                    $('#<?=$id?>').val('');
                    $('#<?=$id?>-img').attr('src', '');
                    $('.<?=$id?>-delete').hide();
                });
            </script>
            <style>.<?=$id?>-delete{display: none;<?= ($dbval != "") ? 'display: block;' : '' ?> color: white;font-weight: bold;cursor: pointer;position: absolute;top: -10px;right: -10px;border: 2px solid red;border-radius: 50px;text-align: center; width: 18px;height: 18px;background-color: red;}
                .images_parent_class{display: inline-block;position:relative;width: 150px;height: 150px;}
                .images_parent_class img{max-width:100%;width:100%;height:auto;}.<?=$id?>_imagearea {float: right;}</style>
         
<?php  }//ends wp uploads
/********************|13.SELECT KEY VALUE ARRAY|**********************/
public function select_key_val($name, $id, $dbval = null, $req = null, $desc = null,$kv_arr, $css_class = null) {?>  
    
 <select class="form-control <?=($css_class != ""?$css_class:'');?>" id="<?=$id?>" name="<?=$name?>" <?=($req != ""?'required="required"':'');?>>
    <option value=''>Select</option>
    <?php  foreach ($kv_arr as $key => $value) {?>
    <option value='<?=$key?>' <?=($key==$dbval)?"selected='selected'":'';?>><?= ucfirst($value);?></option>
    <?php     }?>
</select>
              <div class="desc"><?=$desc!=""?$desc:'';?></div>
      
<?php  }
/********************|14.SELECT WP QUERY|**********************/
public function select_wpquery($name, $id, $dbval = null, $req = null, $desc = null,$wpquery,$key,$value, $css_class = null) {?>  
    
 <select class="form-control <?=($css_class != ""?$css_class:'');?>" id="<?=$id?>" name="<?=$name?>" <?=($req != ""?'required="required"':'');?>>
    <option value=''>Select</option>
    <?php  foreach ($wpquery as $row) {?>
    <option value='<?=$row->$key?>' <?=($row->$key==$dbval)?"selected='selected'":'';?>><?= ucfirst($row->$value);?></option>
    <?php     }?>
</select>
<div class="desc"><?=$desc!=""?$desc:'';?></div>

<?php  }
/* clean a string */
private function clean($str) {
    // Remove all characters except A-Z, a-z, 0-9
    $str = preg_replace('/[^A-Za-z0-9 -_]/', ' ', $str);
    // Replace sequences of spaces 
    $str = preg_replace('/  */', ' ', $str);
    $str = preg_replace('/-/', ' ', $str);
    $str = preg_replace('/_/', ' ', $str);
    return $str;
}
/*******ENDS FORMS FIELDS*******/
function months() {
    $months = array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');
    return $months;
}
function years() {
    $y = range(1970, 2020);
    $years = array_reverse($y);
        return $years;
}

}