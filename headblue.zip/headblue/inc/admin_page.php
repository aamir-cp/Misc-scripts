<?php

 // Set class property
        $this->options = get_option( $this->option_name );
        ?>
<style>._page_title{font-size:22px !important;background: #0073AA;border: 1px solid #007CBA;padding:15px 5px !important;color: #FFF;text-align: center;width: 99.9%;}label{text-transform: capitalize;}
input[type=text],textarea,select{width:350px;padding:3px 5px;}.desc{font-style: italic;font-size: 12px;margin-left: 4px;display: inline;font-size:16px;}
.lead {max-width: 60px;padding: 10px 12px !important;} textarea#map{    width: 90%;    padding: 8px 15px;    height: 97px;    resize: none;}
.wp-admin select {padding: 8px;line-height: 37px;height: 37px;vertical-align: middle;}
</style>

        <div class="wrap">
            <h1 class="_page_title"><?=$this->page_title?></h1>
            <?php  #########print_r($this->fields_arr);
            //foreach($this->fields_arr as $one){ //echo $one['type'].'<br>';}?>
            <form method="post" action="options.php">
            <?php
                // This prints out all hidden setting fields
                settings_fields( $this->option_group );
                do_settings_sections( $this->page_slug );
                submit_button();
            ?>
            </form>
        </div>
<script>
var $ = jQuery;
jQuery(document).ready(function ($) {//ONLY ALLOW INT OR FLOAT
    $('input.float').on('input', function() {
        this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');
    });
});
</script>	
