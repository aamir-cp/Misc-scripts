<?php
/* 
 * Plugin Name: HeadBlue
 * Author: 
 * Plugin URI: n/a
 * Author URI: n/ya
 * Version: 1
 * Description: Managing headblue leads & users
 * Text Domain: hb 
 */
//
global $options;
$options = get_option('questions');//$this->option_name

$_SESSION['cpt'] = 'questions';//$this->parent_slug
$_SESSION['single_name'] = 'question';//$this->cpt_single
//$_SESSION['taxonomy'] = 'Types';//$this->taxonomy
//$_SESSION['single_taxonomy'] = 'Type';//$this->taxonomy_single

// FRONTEND STYLESHEETS 
function hb_styles(){
//    wp_enqueue_style( 'bootstrap',   "https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css");
//    wp_enqueue_style( 'fa',   "https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css");
//    wp_enqueue_style( 'frontend_css',  plugin_dir_url( __FILE__ ) . "assets/style.css");
//    wp_enqueue_style( 'poppins',   "https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;1,100;1,200;1,300;1,400;1,500;1,600&display=swap");
}
//add_action( 'wp_enqueue_scripts', 'hb_styles',10 );



if( is_admin() ){include_once 'inc/class_settings_page.php';
$my_settings_page = new HbSettingsPage();}
/////////////
include('pt.php');
include('hb_form.php');
include('inc/user_meta.php');