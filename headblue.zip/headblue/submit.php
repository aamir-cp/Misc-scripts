<?php require('./../../../wp-load.php'); ?><?php

//print_r($_POST);
$name = $_POST['name'];
$radius = $_POST['radius'];

$agency = $_POST['agency'];
$email_user = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];

$leadPrice = $_POST['leadPrice'];
$totalLeads = $_POST['totalLeads'];

$user_id = wp_create_user($name, $password, $email_user);
if ($user_id) {
    $id_check = true;
}
///
wp_update_user(
        array(
            'ID' => $user_id,
            'nickname' => $_POST['name']
        )
);
//

update_user_meta( $user_id, 'name', $name );
update_user_meta( $user_id, 'radius', $radius );

update_user_meta( $user_id, 'agency', $agency );
update_user_meta( $user_id, 'name', $name );
update_user_meta( $user_id, 'email', $email_user );
update_user_meta( $user_id, 'phone', $phone );
update_user_meta( $user_id, 'password', $password );
update_user_meta( $user_id, 'terms', $terms );

update_user_meta( $user_id, 'totalLeads', $totalLeads );
update_user_meta( $user_id, 'leadPrice', $leadPrice );

$user = new WP_User( $user_id );
$user->add_role( 'subscriber' );

 wp_signon(array('user_login' => $user->email, 'user_password' => $password));
 
//function headblue_auto_login_new_user( $user_id ) {
//    wp_set_current_user( $user_id );
//    wp_set_auth_cookie( $user_id, false, is_ssl() );
//}
//add_action( 'user_register', 'headblue_auto_login_new_user' );

//WOO
global $woocommerce;
$options = get_option('hb_options');
//add to cart multiplied by number of leads
//if($leadPrice == 30){ $prod_to_add = $options['leadprod1'];}
//elseif($leadPrice == 25){ $prod_to_add = $options['leadprod2'];}
//elseif($leadPrice == 22){ $prod_to_add = $options['leadprod3'];}
//elseif($leadPrice == 20){ $prod_to_add = $options['leadprod4'];}
//elseif($leadPrice == 18){ $prod_to_add = $options['leadprod5'];}
//elseif($leadPrice == 15){ $prod_to_add = $options['leadprod6'];}

if($radius <= 2){ $prod_to_add = $options['leadprod1'];}
elseif($radius <= 5){ $prod_to_add = $options['leadprod2'];}
elseif($radius <= 10){ $prod_to_add = $options['leadprod3'];}
elseif($radius <= 25){ $prod_to_add = $options['leadprod4'];}
elseif($radius <= 50){ $prod_to_add = $options['leadprod5'];}
elseif($radius <= 100){ $prod_to_add = $options['leadprod6'];}
WC()->cart->add_to_cart( $prod_to_add,  $totalLeads);
//if( WC()->cart->find_product_in_cart( $prod_to_add ) ){
    echo 1;
//}else{
//    return 0;
//}
 
    
//$user_login     = esc_attr($_POST["email"]);
//$user_password  = esc_attr($_POST["password"]);
//$user_email     = esc_attr($_POST["email"]);

//$user_data = array(
//    'user_login'    =>      $user_login,
//    'user_pass'     =>      $user_password,
//    'user_email'    =>      $user_email,
//    'role'          =>      'subscriber'
//);

// Inserting new user to the db
//wp_insert_user( $user_data );

//$creds = array();
//$creds['user_login'] = $user_login;
//$creds['user_password'] = $user_password;
//$creds['remember'] = true;
//
//$user = wp_signon( $creds, false );
//@$userID = $user->ID;
//
//
//wp_set_current_user( $userID, $user_login );
//wp_set_auth_cookie( $userID, true, false );
//do_action( 'wp_login', $user_login );


//if ( is_user_logged_in() ) {
//    global $current_user;
//    wp_get_current_user();
//}else{
//    echo 'Err!';
//}
