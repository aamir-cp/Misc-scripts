<?php require('./../../../wp-load.php'); ?><?php

     $user = get_user_by( 'email', $_POST['theEmail'] );
$user_id = $user->ID;
// print_r($_POST['email']);   

for ($x = 1; $x < 100; $x++) {
    if($_POST["question$x"] != ""){
    update_user_meta( $user_id, "question".$x, $_POST["question$x"]); 
    }
}
 //LOGIN USER

$location = site_url().'/1';
wp_redirect($location);

//
/**
 * Dynamically pre-populate Woocommerce checkout fields with exact named meta field
 * Eg. field 'shipping_first_name' will check for that exact field and will not fallback to any other
 *  field eg 'first_name'
 */
add_filter('woocommerce_checkout_get_value', function($input, $key) {
	
	global $current_user;
	
	// Return the user property if it exists, false otherwise
	return ($current_user->$key
		? $current_user->$key
		: false
	      	);
}, 10, 2);
?>